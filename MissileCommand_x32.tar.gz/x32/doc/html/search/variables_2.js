var searchData=
[
  ['duration',['duration',['../structexplosions.html#aa161099aa04c46f97a67da777c2f280c',1,'explosions']]],
  ['dx',['dx',['../structmissiles.html#a525091ba874e88da2fc4ba6306ba3e5a',1,'missiles']]],
  ['dy',['dy',['../structmissiles.html#afce72984bdcd3c45d23d5e9cf6034c15',1,'missiles']]]
];
