var searchData=
[
  ['internal_5fradius',['internal_radius',['../structexplosions.html#a7342e8f7d06e50ee18af16688b89e042',1,'explosions']]]
];
