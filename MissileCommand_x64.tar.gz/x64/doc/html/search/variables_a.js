var searchData=
[
  ['radius',['radius',['../structexplosions.html#a6438a86fc61e5160969071601ace0a7f',1,'explosions']]]
];
