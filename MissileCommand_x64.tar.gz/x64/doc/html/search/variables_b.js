var searchData=
[
  ['score',['score',['../main_8cc.html#a9dffb288f0f2281a0b9abbd8efaa5a18',1,'score():&#160;main.cc'],['../main__header_8h.html#a9dffb288f0f2281a0b9abbd8efaa5a18',1,'score():&#160;main.cc']]],
  ['screen_5fh',['SCREEN_H',['../main_8cc.html#a42c075b5e54349391d38c5d53c4eddde',1,'SCREEN_H():&#160;main_header.h'],['../main__header_8h.html#a42c075b5e54349391d38c5d53c4eddde',1,'SCREEN_H():&#160;main_header.h']]],
  ['screen_5fw',['SCREEN_W',['../main_8cc.html#afca0db9c0e472d6c9aefd3022751d0ba',1,'SCREEN_W():&#160;main_header.h'],['../main__header_8h.html#afca0db9c0e472d6c9aefd3022751d0ba',1,'SCREEN_W():&#160;main_header.h']]],
  ['spawn_5fx',['spawn_x',['../structmissiles.html#a393c7504891bdd97504573ea25c4753f',1,'missiles']]],
  ['spawn_5fy',['spawn_y',['../structmissiles.html#a0768fff77af3e0b0885a85a1e364f656',1,'missiles']]],
  ['sx',['sx',['../structmissiles.html#a6788a1d8ea367b7b35103f09f34c1f30',1,'missiles']]],
  ['sy',['sy',['../structmissiles.html#a99d7f6acff019d8480e22f4a530583bf',1,'missiles']]]
];
